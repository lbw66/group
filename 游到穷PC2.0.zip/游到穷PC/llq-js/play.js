var mtlJson = {title:["港澳台 国内","日本韩国","东南亚 南亚","欧洲 美洲","澳新 中东非","全球WIFI 全球接送机",],
        main:[["香港","澳门","台湾",],["首尔","东京","大阪","北海道"],["清迈","新加坡","巴厘岛","不丹"],["英国","西班牙","法国","土耳其"],["澳大利亚","新西兰","摩洛哥"],["WIFI电话卡","设备租赁"]]}
var mtl_ul1 = document.getElementById("mtl_ul1");
for(var mtl1 = 0;mtl1<mtlJson.title.length;mtl1++){
    mtl_ul1.innerHTML +="<li><p>" +mtlJson.title[mtl1]+ "</p></li>";
    var mtl_li = mtl_ul1.getElementsByTagName("li")[mtl1];
    for(var mtl2 = 0;mtl2<mtlJson.main[mtl1].length;mtl2++){
        console.log(mtl1);
        mtl_li.innerHTML +="<span>"+mtlJson.main[mtl1][mtl2]+"</span>"
        if(mtl2 == mtlJson.main[mtl1].length-1){
            mtl_li.innerHTML +="<img src='llq-img/右.png'>"
        }
    }
}

// 当地玩乐
var mc1Json = {img:[1,1,1,1,1,1,1,1],price:[299,298,297,296,295,294,293,292],
        main:["新加坡环球影城主题公园门票（电子票）","新加坡环球影城主题公园门票（电子票）","新加坡环球影城主题公园门票（电子票）","新加坡环球影城主题公园门票（电子票）","新加坡环球影城主题公园门票（电子票）","新加坡环球影城主题公园门票（电子票）","新加坡环球影城主题公园门票（电子票）","新加坡环球影城主题公园门票（电子票）",]}
var mc1_main = document.getElementById("mc1_main");
for(var mc1a = 0;mc1a<mc1Json.img.length;mc1a++){
    mc1_main.innerHTML += "<li><div><img src='llq-img/play-b-"+mc1Json.img[mc1a]+".jpg'></div><p>"+mc1Json.main[mc1a]+"</p><span><em>"+mc1Json.price[mc1a]+"</em>元起</span></li>"
}

// 优选特惠
var mcJson = {
    title1:["优选特惠","玩转全球","优选特惠"],
    title2:["集合热门目的地玩法与热选商品，从此告别选择困难症","像当地人一样，体验本土吃喝玩乐","集合热门目的地玩法与热选商品，从此告别选择困难症"],
    disp:["block","block","none"],
    bk:["#ff6476,#ff7467","#61d482,#16cbb3","#b274c7,#4e8cdb"],
    title3:["东南亚 南亚","日本 韩国","欧洲 美洲"],
    ml1:[["新加坡","吉普","巴沙","新加坡","吉普","巴沙","新加坡","吉普","巴沙"],["新加坡","吉普","巴沙","新加坡","吉普","巴沙","新加坡","吉普","巴沙"],["伦敦","巴黎","纽约","冰岛","佛罗伦萨"]],
    ml2:[["丛林飞跃","海岛浮潜","圣淘沙","新加坡环球影城","丛林飞跃"],["丛林飞跃","海岛浮潜","圣淘沙","新加坡环球影城","丛林飞跃"],["塞纳河游船","伦敦眼","山水瑞士","西甲球票","伦敦戏剧","美西大峡谷"]],
    imgB:[1,1,3],
    imgS:[[2,2,2,2],[2,2,2,2],[4,4,4,4]],
    mainB1:["与泰国一起 为美食疯狂","与泰国一起 为美食疯狂","着色地中海 火辣巴塞罗那"],
    mainB2:["曼谷+清迈人气餐厅大盘点","曼谷+清迈人气餐厅大盘点","360度嗨玩巴萨"],
    mainS1:[["与泰国一起 为美食疯狂","与泰国一起 为美食疯狂","与泰国一起 为美食疯狂","与泰国一起 为美食疯狂"],["与泰国一起 为美食疯狂","与泰国一起 为美食疯狂","与泰国一起 为美食疯狂","与泰国一起 为美食疯狂"],["美国西部大峡谷观景","美国西部大峡谷观景","美国西部大峡谷观景","美国西部大峡谷观景"]],
    mainS2:[["曼谷+清迈人气餐厅大盘点","曼谷+清迈人气餐厅大盘点","曼谷+清迈人气餐厅大盘点","曼谷+清迈人气餐厅大盘点"],["曼谷+清迈人气餐厅大盘点","曼谷+清迈人气餐厅大盘点","曼谷+清迈人气餐厅大盘点","曼谷+清迈人气餐厅大盘点"],["翻开一页“活的地质史教科书”","翻开一页“活的地质史教科书”","翻开一页“活的地质史教科书”","翻开一页“活的地质史教科书”"]]
}
var main = document.getElementById("main");
for(var mc = 0;mc<mcJson.title1.length;mc++){
    main.innerHTML += "<div class='main-cen'><div class='mc-title' style='display:"+ mcJson.disp[mc]+";'><h1>"+mcJson.title1[mc]+"</h1><span>" +mcJson.title2[mc]+ "</span></div><div class='mc-main'><div class='mcm-left' style='background:linear-gradient(180deg,"+mcJson.bk[mc]+")'><h1>"+
        mcJson.title3[mc]+"</h1><div class='mcml-center'></div><p>热卖推荐</p><div class='mcml-bottom'></div></div><ul class='mcm-right'><li class='bigLi'><img src='llq-img/play-c-"+mcJson.imgB[mc]+".jpg'><div><h5>"+mcJson.mainB1[mc]+"</h5><span>"+mcJson.mainB2[mc]+"</span></div></li></ul></div></div>";
    var mcml_c = document.getElementsByClassName("mcml-center")[mc];
    var mcml_b = document.getElementsByClassName("mcml-bottom")[mc];
    var mcm_r = document.getElementsByClassName("mcm-right")[mc];
    for(var mc1 = 0;mc1<mcJson.ml1[mc].length;mc1++){
        mcml_c.innerHTML +="<a href='#'>"+mcJson.ml1[mc][mc1]+"</a>";
    }
    for(var mc2 = 0;mc2<mcJson.ml2[mc].length-1; mc2++){
        mcml_b.innerHTML += "<span>"+mcJson.ml2[mc][mc2]+"</span><h5></h5>"
        if(mc2 == mcJson.ml2[mc].length-2){
            mcml_b.innerHTML += "<span>"+mcJson.ml2[mc][mcJson.ml2[mc].length-1]+"</span>"
        }
    }
    for(var mc3 = 0;mc3<mcJson.imgS[mc].length;mc3++){
        mcm_r.innerHTML +="<li class='smLi'><img src='llq-img/play-c-" +mcJson.imgS[mc][mc3]+ ".jpg'><div><h5>" +mcJson.mainS1[mc][mc3]+ "</h5><span>" +mcJson.mainS2[mc][mc3]+ "</span></div></li>";
    }
    if(mc == 1){
        main.innerHTML +="<ul id='main_bottom'></ul>"
    }
}
// 门票
var mbJson = {title:["门票服务","门票服务","门票服务"],
            img:["门票","美食","bus"],
            main:[["黄金海岸主题公园套票","悉尼超值组合","考拉保护中心","毛利文化"],["黄金海岸主题公园套票","悉尼超值组合","考拉保护中心","毛利文化"],["黄金海岸主题公园套票","悉尼超值组合","考拉保护中心","毛利文化"]]

}
var main_bottom = document.getElementById("main_bottom");
for(var mb = 0;mb<mbJson.title.length;mb++){
    main_bottom.innerHTML +="<li><p>"+mbJson.title[mb]+"</p><div class='mb_a'><div><img src='llq-img/"+mbJson.img[mb]+".png'></div><div class='mba_sp'></div></div></li>"
    var mbs_sp = document.getElementsByClassName("mba_sp")[mb];
    for(var mb1 = 0;mb1<mbJson.main[mb].length;mb1++){
        mbs_sp.innerHTML +="<span>"+mbJson.main[mb][mb1]+"</span>";
    }
}