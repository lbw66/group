// 正则
    var CN = /^[\u4e00-\u9fa5]{0,}$/;
    var phoneNmb = /^(13[0-9]|14[5|7]|15[0|1|2|3|5|6|7|8|9]|18[0|1|2|3|5|6|7|8|9])\d{8}$/
    var e_mail = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
// 姓名
var mName = document.getElementById("mName");
var tips = document.getElementsByClassName("tips");
mName.onblur = function(){
    console.log(1)
    if(mName.value==""){
        tips[0].innerHTML = "姓名不能为空";
    }else if(!CN.test(mName.value)){
        tips[0].innerHTML = "请输入中文名";
    }else{
        tips[0].innerHTML = "";
    }
}
// 出生年月
var ymJsom = {
    year1:[201,200,199,198,197,196,195,194,193,192,191,190],
    year2:[9,8,7,6,5,4,3,2,1,0],
    month:[1,2,3,4,5,6,7,8,9,10,11,12]
}
var getY = document.getElementById("getYear");
var getM = document.getElementById("getMonth");
for(var ym1=0;ym1<ymJsom.year1.length;ym1++){
    for(var ym2=0;ym2<ymJsom.year2.length;ym2++){
        getY.innerHTML += "<option>"+ ymJsom.year1[ym1]+ymJsom.year2[ym2]+"年</option>"
    }
}
for(var ym3= 0;ym3<ymJsom.month.length;ym3++){
    getM.innerHTML += "<option>"+ymJsom.month[ym3]+"月</option>"
}
// getM.
console.log(getM.value);
// 国籍
var country = document.getElementById("country");
var otherC = document.getElementById("otherC");
country.onclick = function(){
    if(country.value == "其他"){
        otherC.style.display = "inline-block";
        otherC.onblur = function(){
            if(otherC.value==""){
                tips[1].innerHTML = "国籍不能为空";
            }else if(!CN.test(otherC.value)){
                tips[1].innerHTML = "请输入中文国家名";
            }else{
                tips[1].innerHTML = "";
            }
        }
    }else{
        otherC.style.display = "none";
        tips[1].innerHTML = "";
    }
}
// 电话号码
var phone = document.getElementById("phone");
phone.onblur = function(){
    if(phone.value == ""){
        tips[2].innerHTML = "请输入手机号";
    }else if(!phoneNmb.test(phone.value)){
        tips[2].innerHTML = "请输入正确的手机号";
    }else{
        tips[2].innerHTML = "";
    }
}
// 邮箱
var em = document.getElementById("email");
em.onblur = function(){
    if(em.value == ""){
        tips[3].innerHTML = "请输入邮箱";
    }else if(!e_mail.test(em.value)){
        tips[3].innerHTML = "请输入正确的邮箱";
    }else{
        tips[3].innerHTML = "";
    }
}
// 地址
var where = document.getElementById("where");
where.onblur = function(){
    if(where.value == ""){
        tips[4].innerHTML = "请输入地址";
    }else{
        tips[4].innerHTML = "";
    }
}

var inp = document.getElementsByClassName("inp");
var go =document.getElementById("go");
go.onclick = function(){
    if(mName.value == ""){
        alert("请输入姓名");
    }else if(phone.value == ""){
        alert("请输入手机号码")
    }else if(email.value == ""){
        alert("请输入邮箱")
    }else if(where.value == ""){
        alert("请输入地址")
    }else{
        for(var ts = 0;ts<tips.length;ts++){
            if(tips[ts].innerHTML !=""){
                alert("请填写正确信息");
                break;
            }
            if(ts == tips.length-1){
                alert("保存成功");
            }
        }
    }
}
// 添加证件 
var goFile = document.getElementById("goFile");
var getFile = document.getElementById("getFile");
var fileW = document.getElementById("fileW");
goFile.onclick = function(){    
    getFile.click();
    goFile.onchange = function(){
        console.log(getFile.value)
        fileW.innerHTML = getFile.value;
        if(this.value==""){
            word.innerHTML = "请选择文件"
        }
    }
}
