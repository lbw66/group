// 轮播图
var mtUl1 = document.getElementById("mt-ul1");
var mtUl2 = document.getElementById("mt-ul2");
var mtLi1 = mtUl1.getElementsByTagName("li");
var mtLi2 = mtUl2.getElementsByTagName("li");
var lbtl = document.getElementsByClassName("lbt-l")[0];
var lbtr = document.getElementsByClassName("lbt-r")[0];
var now = 0;

function go(){
    for(var i =0;i<mtLi2.length;i++){
        mtLi2[i].className="";
        mtLi1[i].style.opacity = "0";
    }
    mtLi2[now].className="mtOn";
    mtLi1[now].style.opacity = "1";
}
function next(){
    now++;
    if(now == mtLi2.length){
        now = 0;
    }
    go();
}
function back(){
    now--;
    if(now == -1){
        now = mtLi2.length-1;
    }
    go();
}
var times = null;
times = setInterval(next,1500)

mtUl1.onmouseover = function(){
    clearInterval(times);
};
mtUl1.onmouseout = function(){
    times = setInterval(next ,1500)
};
mtUl2.onmouseover = function(){
    clearInterval(times);
};
mtUl2.onmouseout = function(){
    times = setInterval(next ,1500)
};
for(var z = 0;z<mtLi2.length;z++){
    mtLi2[z].index = z;
    mtLi2[z].onmouseover = function(){
        now = this.index;
        go();
    };
}
lbtl.onclick = function(){
    clearInterval(times);
    back();
    times = setInterval(next,1500);
}
lbtr.onclick = function(){
    clearInterval(times);
    next();
    times = setInterval(next,1500);
}

// 行业新闻
    var mlJson = {title:["悦榕集团旗下四家悦榕庄，新推春季入住“鲜”体验","食在东京香格里拉大酒店","东京香格里拉大酒店CHI水疗","东京香格里拉大酒店优雅套房","布达拉宫“今冬首轮”免费游进入倒计时","为了那片神奇的土地——记经济学博士汪良忠和他的伙伴们",
                            "中青旅遨游网发布90后小假期旅游消费习惯报告：旅行更看重“自由”“超值轻奢”受追崇","多个旅游景区打“花牌”招揽游客 出境赏樱价看涨"],
        main:["春风又临，悦榕集团旗下黄山、阳朔、丽江、仁安四家悦榕庄已初见春意。为满足宾客赏花踏青、出游度假的需求，四家悦榕庄分别结合本地特色推出春季入住套餐，诚邀宾客前往欣赏自然美景、度过春日美好时光。 山间访",
                " 东京香格里拉大酒店拥有两家餐厅——Piacere 意式餐厅和滩万日本料理，外加大堂酒廊。酒店的招牌意式餐厅“Piacere”和正宗日本怀石料理餐厅“滩万”均由香港 AFSO 公司前途无量的室内设计师",
                " 随着东京香格里拉大酒店的开业，香格里拉 CHI 水疗 首次登陆日本。该 Spa中心设有六间宽敞宁静的 Spa 套房（包括一间双人水疗套房），所有CHI 水疗中心均有提供的各式招牌 CHI 水疗疗法以",
                " 东京香格里拉大酒店拥有 200 间空间开阔、装修优雅的客房及套房。其中，十六间奢华套房以公寓式生活为灵感来源，坐拥东京繁华都市风光，缔造独一无二的奢华放松氛围。每间套房各具特色，专为品味人士设计，是",
                " 原标题：布达拉宫“今冬首轮”免费游进入倒计时 新华社拉萨3月12日电（记者春拉）记者从布达拉宫管理处获悉，2019年西藏首轮跨年“冬游西藏”活动将于本月15日结束，16日起，包括布达拉宫等在内的免费",
                " 东京香格里拉大酒店拥有两家餐厅——Piacere 意式餐厅和滩万日本料理，外加大堂酒廊。酒店的招牌意式餐厅“Piacere”和正宗日本怀石料理餐厅“滩万”均由香港 AFSO 公司前途无量的室内设计师",
                " 随着东京香格里拉大酒店的开业，香格里拉 CHI 水疗 首次登陆日本。该 Spa中心设有六间宽敞宁静的 Spa 套房（包括一间双人水疗套房），所有CHI 水疗中心均有提供的各式招牌 CHI 水疗疗法以",
                " 东京香格里拉大酒店拥有 200 间空间开阔、装修优雅的客房及套房。其中，十六间奢华套房以公寓式生活为灵感来源，坐拥东京繁华都市风光，缔造独一无二的奢华放松氛围。每间套房各具特色，专为品味人士设计，是",],
        img:[1,2,3,4,5,6,7,8]}
    var ml_center = document.getElementById("ml_center");
    for(var ml1 = 0 ;ml1<mlJson.title.length;ml1++){
        ml_center.innerHTML += "<li><img src='llq-img/news-b-"+ mlJson.img[ml1] +".jpg'><div class='ml_center_right'><p>"+ mlJson.title[ml1]+"</p><a href='#'>" + 
            mlJson.main[ml1] +"</a><div><a href='#'><img src='llq-img/qqicon.jpg'>游到穷GOGOGO</a><i>前去评论</i></div></div></li>";
    }
// 右边选项卡
    var mrJson = {mrc1:{img:[1,2],name:["牛牛牛牛牛","niuniuniuniuniu"],look:[14567,5481],
            main:["欧洲海拔最高的火车站，打卡欧洲之巅瑞士少女峰！#Ｊ调旅行生活VLOG# #旅行新势力# #瑞士旅行J调de华丽jiajiatravel的秒拍视频（上#秒拍#看我的最新短视频，下载秒拍->http://",
                    "#共同旅行#吃货的旅行！不可辜负的16种泰国美食凯德印象的秒拍视频（上#秒拍#看我的最新短视频，下载秒拍->http://t.cn/Rjc3iXC）"]},
            mrc2:{img:[1,2],main:["清净而典雅的慕尼黑","加拿大班夫国家公园，大山里独特的浪漫"]},
            mrc3:{title:["#王珞丹慢游新西兰#","#王珞丹慢游新西兰#"],main:["互联网首档明星深度体验式旅行生活方式纪录节目#慢游全世界#第二季#王珞丹慢游新西兰#。跟随@王珞丹 开启不一样的味觉探险。","互联网首档明星深度体验式旅行生活方式纪录节目#慢游全世界#第二季#王珞丹慢游新西兰#。跟随@王珞丹 开启不一样的味觉探险。"],
                    img:[1,1],time:["2018年05月16日 - 2018年06月08日","2018年05月16日 - 2018年06月08日"],p1:["20051312","20051312"],p2:["16080","16080"]}}
    var mr_center_1 = document.getElementById("mr_center_1");
    var mr_center_2 = document.getElementById("mr_center_2");
    var mr_center_3 = document.getElementById("mr_center_3");
    var mrUl1 = document.getElementsByClassName("mr-title")[0];
    var mrLi2 = document.getElementsByClassName("mr-center");
    var mrLi1 = mrUl1.getElementsByTagName("li")
    for(var mc1 = 0;mc1<mrJson.mrc1.img.length;mc1++){
        mr_center_1.innerHTML += "<li><img src='llq-img/news-c-" + mrJson.mrc1.img[mc1]+ ".jpg'><div class=mr_c_1_user><img src='llq-img/qqicon.jpg'><span>"+
            mrJson.mrc1.name[mc1]+"</span><div><img src='llq-img/浏览.png'><span>"+mrJson.mrc1.look[mc1]+"</span></div></div><a href='#'>"+
            mrJson.mrc1.main[mc1]+"</a></li>"
        if(mc1==mrJson.mrc1.img.length-1){
            mr_center_1.innerHTML +="<h5 class='lookMore'>查看更多</h5>";
        }
    }
    for(var mc2 = 0;mc2<mrJson.mrc2.img.length;mc2++){
        mr_center_2.innerHTML +="<li><img src='llq-img/news-d-"+mrJson.mrc2.img[mc2]+".jpg'><p>"+mrJson.mrc2.main[mc2]+"</p></li>";
        if(mc2==mrJson.mrc2.img.length-1){
            mr_center_2.innerHTML +="<h5 class='lookMore'>查看更多</h5>";
        }
    }
    for(var mc3 = 0;mc3<mrJson.mrc3.img.length;mc3++){
        mr_center_3.innerHTML +="<li><img src='llq-img/news-e-"+mrJson.mrc3.img[mc3]+".jpg'><h1>"+mrJson.mrc3.title[mc3]+"</h1><h2>"+ 
            mrJson.mrc3.main[mc3]+"</h2><h3>"+mrJson.mrc3.time[mc3]+"</h3><span><em>"+mrJson.mrc3.p1[mc3]+"</em>人 感兴趣</span><span><em>"+ mrJson.mrc3.p2[mc3]+"</em>人 参与</span></li>"
        if(mc3==mrJson.mrc3.img.length-1){
            mr_center_3.innerHTML +="<h5 class='lookMore'>查看更多</h5>";
        }
    }
for(var tab1=0;tab1<mrLi1.length;tab1++){
    mrLi1[tab1].index=tab1;
    mrLi1[tab1].onclick = function(){
        for(var tab2 = 0;tab2<mrLi1.length;tab2++){
            mrLi1[tab2].className = "";
            mrLi2[tab2].style.display = "none";
        }
        this.className = "mrOn";
        mrLi2[this.index].style.display = "block";
    }
}
   