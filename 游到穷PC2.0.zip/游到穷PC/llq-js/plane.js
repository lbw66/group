  // 轮播图
  var lbt = document.getElementById("lbt");
  var timg = document.getElementById("timg");
  var tmini = document.getElementById("tmini");
  var imgs = timg.getElementsByTagName("li");
  var minis = tmini.getElementsByTagName("li");
  var now = 0;
  function go() {//显示效果
    for (var i = 0; i < imgs.length; i++) {
      minis[i].className = "";
      imgs[i].style.opacity = "0";
    }
    minis[now].className = "imgon";
    imgs[now].style.opacity = "1";
  }
  function next() {//轮播
    now++;
    if (now == imgs.length) {
      now = 0;
    }
    go();
  }
  var times = null;
//   计时器的开启与关闭
  times = setInterval(next, 1500);
  lbt.onmouseover = function() { 
    clearInterval(times);
  };
  lbt.onmouseout = function() {
    times = setInterval(next, 1500);
  };
  for (let z = 0; z < minis.length; z++) {// 小图标效果
    minis[z].index = z;
    minis[z].onmouseover = function() {
      now = this.index;
      go();
    };
  }
//   机票top
  var sp_ul1 = document.getElementById("sp_ul1");
  var sp_li1 = sp_ul1.getElementsByTagName("li");
  var sp_li2 = document.getElementsByClassName("sp_ul");
  for(var sp = 0;sp<sp_li1.length;sp++){
      sp_li1[sp].index = sp;
      sp_li1[sp].onclick = function(){
        for(var sp1 = 0;sp1<sp_li1.length;sp1++){
            sp_li1[sp1].className = "";
            sp_li2[sp1].style.display = "none";
        }
        this.className = "spOn";
        sp_li2[this.index].style.display = "block";
      }
  }
//   机票服务
var pmcJson = {title:["北京","上海","杭州","长沙"],
            now:["杭州","杭州","杭州","杭州"],
            go:["北京","上海","杭州","长沙"],
            time:["3月6日","3月6日","3月6日","3月6日"],
            price:[445,444,443,442],
            img:[1,1,1,1]
}
var pmc_main = document.getElementById("pmc_main");
for(var pmc = 0;pmc<pmcJson.title.length;pmc++){
    pmc_main.innerHTML += "<li><img src='llq-img/plane-a-"+ pmcJson.img[pmc] +".jpg'><h2>"+pmcJson.title[pmc]+"</h2><div class='pmc-go'><h1>"+pmcJson.now[pmc]+"</h1><img src='llq-img/右箭头.png'><h1>" + 
        pmcJson.go[pmc]+ "</h1></div><h3>" +pmcJson.time[pmc]+ "</h3><span>￥<em>"+ pmcJson.price[pmc]+"</em></span></li>"
}

// 特价机票
var pmpJson = {now:["北京","上海","广州","长沙",],
    go:[[["成都","成都","成都","成都","成都","成都"],["深圳","深圳","深圳","深圳","深圳","深圳"],["重庆","重庆","重庆","重庆","重庆","重庆"]],
        [["昆明","昆明","昆明","昆明","昆明","昆明"],["厦门","厦门","厦门","厦门","厦门","厦门"],["长沙","长沙","长沙","长沙","长沙","长沙"]],
        [["福州","福州","福州","福州","福州","福州"],["哈尔滨","哈尔滨","哈尔滨","哈尔滨","哈尔滨","哈尔滨"],["武汉","武汉","武汉","武汉","武汉","武汉"]],
        [["大连","大连","大连","大连","大连","大连"],["海口","海口","海口","海口","海口","海口"],["宁波","宁波","宁波","宁波","宁波","宁波"]]],
    time:[[["04-06","04-06","04-06","04-06","04-06","04-06"],["03-15","03-15","03-15","03-15","03-15","03-15"],["05-13","05-13","05-13","05-13","05-13","05-13"]],
       [["04-13","04-13","04-13","04-13","04-13","04-13"],["04-12","04-12","04-12","04-12","04-12","04-12"],["05-11","05-11","05-11","05-11","05-11","05-11"]],
        [["04-14","04-14","04-14","04-14","04-14","04-14"],["04-15","04-15","04-15","04-15","04-15","04-15"],["05-12","05-12","05-12","05-12","05-12","05-12"]],
        [["05-12","05-12","05-12","05-12","05-12","05-12"],["05-14","05-14","05-14","05-14","05-14","05-14"],["05-15","05-15","05-15","05-15","05-15","05-15"]]],
    price:[[[252,235,325,324,351,654],[252,235,325,324,351,654],[252,235,325,324,351,654]],
        [[252,235,325,324,351,654],[252,235,325,324,351,654],[252,235,325,324,351,654]],
        [[252,235,325,324,351,654],[252,235,325,324,351,654],[252,235,325,324,351,654]],
        [[252,235,325,324,351,654],[252,235,325,324,351,654],[252,235,325,324,351,654]]]
}
var pmp_ul1 = document.getElementById("pmp_ul1");
var pmp_li1 = pmp_ul1.getElementsByTagName("li");
var pmp_ul2 = document.getElementById("pmp_ul2");
var pmp_li2 = pmp_ul2.getElementsByTagName("ul");
for(var pmp = 0;pmp<pmpJson.go[0].length;pmp++){
    for(var pmp0 = 0;pmp0<pmpJson.go[0][pmp].length;pmp0++){
        pmp_li2[pmp].innerHTML += "<li><h1>"+pmpJson.now[0]+" - "+pmpJson.go[0][pmp][pmp0]+"</h1><h2>"+pmpJson.time[0][pmp][pmp0]+"</h2><h3>￥"+pmpJson.price[0][pmp][pmp0]+"</h3></li>"
    }
}
for(var pmp1 = 0;pmp1<pmp_li1.length;pmp1++){
    pmp_li1[pmp1].index = pmp1;
    pmp_li1[pmp1].onclick = function(){
        for(var pmp2 = 0;pmp2<pmp_li1.length;pmp2++){
            pmp_li1[pmp2].className = "";
        }
        this.className = "pmpOn";
        
        pmp_ul2.innerHTML = "<ul class='pmp_li'></ul><ul class='pmp_li'></ul><ul class='pmp_li'></ul>";
        for(var pmp2 = 0;pmp2<pmpJson.go[this.index].length;pmp2++){
            for(var pmp3 = 0;pmp3<pmpJson.go[this.index][pmp2].length;pmp3++){
                pmp_li2[pmp2].innerHTML += "<li><h1>"+pmpJson.now[this.index]+" - "+pmpJson.go[this.index][pmp2][pmp3]+"</h1><h2>"+pmpJson.time[this.index][pmp2][pmp3]+"</h2><h3>￥"+pmpJson.price[this.index][pmp2][pmp3]+"</h3></li>"
            }
        }
    }
}
