window.onload = function() {
    // 轮播图
  var lbt = document.getElementById("lbt");
  var timg = document.getElementById("timg");
  var tmini = document.getElementById("tmini");
  var imgs = timg.getElementsByTagName("li");
  var minis = tmini.getElementsByTagName("li");
  var now = 0;
  function go() {//显示效果
    for (var i = 0; i < imgs.length; i++) {
      minis[i].className = "";
      imgs[i].style.opacity = "0";
    }
    minis[now].className = "imgon";
    imgs[now].style.opacity = "1";
  }
  function next() {//轮播
    now++;
    if (now == imgs.length) {
      now = 0;
    }
    go();
  }
  var times = null;
//   计时器的开启与关闭
  times = setInterval(next, 1500);
  lbt.onmouseover = function() { 
    clearInterval(times);
  };
  lbt.onmouseout = function() {
    times = setInterval(next, 1500);
  };
  for (let z = 0; z < minis.length; z++) {// 小图标效果
    minis[z].index = z;
    minis[z].onmouseover = function() {
      now = this.index;
      go();
    };
  }
//  搜索框
tbJson = {"hot":[["杭州","嘉兴","上海","金华","南京","长沙"],
        ["巴黎","悉尼","马德里","慕尼黑","新加坡"],
        ["澳门","台北","澳门","香港","杭州","上海"]]
    }
  var sA=document.getElementById("top_box").getElementsByTagName("span");
  var showA = document.getElementById("showA");
  for(var saOne = 0;saOne<tbJson.hot[0].length;saOne++){
      showA.innerHTML += "<li>" + tbJson.hot[0][saOne] + "</li>";
  }
  for(var sa = 0;sa<sA.length;sa++){
    sA[sa].index = sa;
    sA[sa].onclick = function(){
        for(var sa1 = 0;sa1<sA.length;sa1++){
            sA[sa1].className="";
        }
        showA.innerHTML = "";
        this.className = "saon";
        for(var sa2 = 0;sa2<tbJson.hot[this.index].length;sa2++){
            showA.innerHTML += "<li>" + tbJson.hot[this.index][sa2]+ "</li>"
        }
    }
  }
  // 热门城市推荐
  var mtJson = {where:[[["全球Top 10 城市","东京","曼谷","香港","台北","新加坡","巴黎","罗马","伦敦","首尔","洛杉矶"],["免签及落地签最热旅行地","济州岛","印度尼西亚","泰国","塞班岛","摩洛哥","卡塔尔","毛里求斯","柬埔寨","厄瓜多尔"],["热门海岛","塞班岛","长滩岛","马尔代夫","沙巴","吉普岛","巴厘岛","芽庄","帕劳","冲绳市"],["热门海岛","塞班岛","长滩岛","马尔代夫","沙巴","吉普岛","巴厘岛","芽庄","帕劳","冲绳市"]],
        [["港澳台","香港","澳门","台北","花莲","高雄市","台中市","九份","台南","淡水","宜兰"],["日本","东京","大阪","京都","冲绳","北海道","名古屋","奈良","札幌","富士山地图"],["韩国","首尔","济州岛","釜山"]],
        [["全球Top 10 城市","东京","曼谷","香港","台北","新加坡","巴黎","罗马","伦敦","首尔","洛杉矶"],["新加坡","新加坡"],["新加坡","新加坡"],["新加坡","新加坡"],["热门海岛","东京","曼谷","香港","台北","新加坡","巴黎","罗马","伦敦","首尔","洛杉矶"]],
        [["港澳台","东京","曼谷","香港","台北","新加坡","巴黎","罗马","伦敦","首尔","洛杉矶"],["日本","东京","曼谷","香港","台北","新加坡","巴黎","罗马","伦敦","首尔","洛杉矶"],["韩国","东京","曼谷","香港","台北","新加坡","巴黎","罗马","伦敦","首尔","洛杉矶"]],
        [["全球Top 10 城市","东京","曼谷","香港","台北","新加坡","巴黎","罗马","伦敦","首尔","洛杉矶"],["免签及落地签最热旅行地","东京","曼谷","香港","台北","新加坡","巴黎","罗马","伦敦","首尔","洛杉矶"],["热门海岛","东京","曼谷","香港","台北","新加坡","巴黎","罗马","伦敦","首尔","洛杉矶"]],
        [["港澳台","东京","曼谷","香港","台北","新加坡","巴黎","罗马","伦敦","首尔","洛杉矶"],["日本","东京","曼谷","香港","台北","新加坡","巴黎","罗马","伦敦","首尔","洛杉矶"],["韩国","东京","曼谷","香港","台北","新加坡","巴黎","罗马","伦敦","首尔","洛杉矶"]],
    ]};
    var mt1=document.getElementById("mt-ul1");
    var mtlis1 =mt1.getElementsByTagName("li");
    var mt2=document.getElementById("mt-ul2");
    for(var mtt1=0;mtt1<mtJson.where[0].length;mtt1++){
      mt2.innerHTML += "<li><p>"+mtJson.where[0][mtt1][0]+"</p></li>";
      var mtlis2 = mt2.getElementsByTagName("li")[mtt1];
      for(var mttm1 = 1;mttm1<mtJson.where[0][mtt1].length;mttm1++){
        mtlis2.innerHTML += "<span>"+mtJson.where[0][mtt1][mttm1]+"</span>";
    }
    }
    for(var i = 0;i<mtlis1.length;i++){
        mtlis1[i].index = i;
        mtlis1[i].onmouseover = function(){
            for(var mtli = 0;mtli<mtlis1.length;mtli++){
                mtlis1[mtli].className = "";
            }
            mt2.innerHTML = "";
            this.className = "mtOn"; 
            for(var mtt = 0;mtt<mtJson.where[this.index].length;mtt++){
                mt2.innerHTML += "<li><p>"+mtJson.where[this.index][mtt][0]+"</p></li>";
                var mtlis2 = mt2.getElementsByTagName("li")[mtt];
                for(var mttm = 1;mttm<mtJson.where[this.index][mtt].length;mttm++){
                    mtlis2.innerHTML += "<span>"+mtJson.where[this.index][mtt][mttm]+"</span>";
                }
            }
        }
    }

    // 主体目的地
    var msJson = [{title:["富士山","太平山","太平山","太平山","太平山","太平山","太平山"],img:[1,2,3,2,2,3,2],
        main:["地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。",]},
        {title:["富士山","太平山","太平山","太平山","太平山","太平山","太平山"],img:[4,2,3,2,3,2,3],
        main:["地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。",]},
        {title:["富士山","太平山","太平山","太平山","太平山","太平山","太平山"],img:[5,3,2,3,2,3,2],
        main:["地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。",]},
        {title:["富士山","太平山","太平山","太平山","太平山","太平山","太平山"],img:[6,2,3,2,3,2,3],
        main:["地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。",]},
        {title:["富士山","太平山","太平山","太平山","太平山","太平山","太平山"],img:[7,3,2,3,2,3,2],
        main:["地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。","地方虽然不大，但却给人一种一尘不染的脱俗感。",]}];
    var msUl1 = document.getElementById("ms-ul1");
    var msl = document.getElementsByClassName("ms-left")[0];
    var msr = document.getElementsByClassName("ms-right")[0];
    var msLis1 = msUl1.getElementsByTagName("li");
    msl.style.backgroundImage = "url(llq-img/des-a-"+msJson[0].img[0]+".jpg)"  //输入左边的背景图片
    msl.innerHTML = "<div class='msl-w'><p>"+msJson[0].title[0]+"<span>"+msJson[0].main[0]+"</span></p></div>";//左图片上附带的内容
    for(var ms1 = 1;ms1<msJson[0].title.length;ms1++){
      msr.innerHTML += "<li class='msr-1'><div class='msr-w'><p>" + msJson[0].title[ms1] + "</p><span>" + msJson[0].main[ms1] + "</span></div></li>"
      var msrLis = msr.getElementsByTagName("li")[ms1-1];
      msrLis.style.backgroundImage = "url(llq-img/des-a-" + msJson[0].img[ms1] + ".jpg)"
    }
    for(var ms2 = 0;ms2<msLis1.length;ms2++){
      msLis1[ms2].index = ms2;
      msLis1[ms2].onmouseover = function(){
        for(var ms3 = 0;ms3<msLis1.length;ms3++){
          msLis1[ms3].className = "";
        }
        this.className = "msOn";
        msl.innerHTML = "";
        msr.innerHTML = "";
        msl.innerHTML = "<div class='msl-w'><p>"+msJson[this.index].title[0]+"<span>"+msJson[this.index].main[0]+"</span></p></div>";
        msl.style.backgroundImage = "url(llq-img/des-a-"+msJson[this.index].img[0]+".jpg)"
        for(var ms5 = 1;ms5<msJson[this.index].title.length;ms5++){
          msr.innerHTML += "<li class='msr-1'><div class='msr-w'><p>" + msJson[this.index].title[ms5] + "</p><span>" + msJson[this.index].main[ms5] + "</span></div></li>"
          var msrLis = msr.getElementsByTagName("li")[ms5-1];
          msrLis.style.backgroundImage = "url(llq-img/des-a-" + msJson[this.index].img[ms5] + ".jpg)"
        }
      }
    }

    // 月度推荐
    var mmJson = [{title:["新西兰","新西兰","新西兰","新西兰","新西兰"],img:[1,1,1,1,1],main:["在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。"]},
    {title:["瑞典","瑞典","瑞典","瑞典","瑞典"],img:[2,2,2,2,2],main:["在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。"]},
    {title:["济州岛","济州岛","济州岛","济州岛","济州岛"],img:[3,3,3,3,3],main:["在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。"]},
    {title:["台湾垦丁","台湾垦丁","台湾垦丁","台湾垦丁","台湾垦丁"],img:[4,4,4,4,4],main:["在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。"]},
    {title:["捷克","捷克","捷克","捷克","捷克"],img:[5,5,5,5,5],main:["在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。"]},
    {title:["桑坦尼亚","桑坦尼亚","桑坦尼亚","桑坦尼亚","桑坦尼亚"],img:[6,6,6,6,6],main:["在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。"]},
    {title:["挪威","挪威","挪威","挪威","挪威"],img:[7,7,7,7,7],main:["在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。"]},
    {title:["俄罗斯贝加尔湖","俄罗斯贝加尔湖","俄罗斯贝加尔湖","俄罗斯贝加尔湖","俄罗斯贝加尔湖"],img:[8,8,8,8,8],main:["在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。"]},
    {title:["意大利米兰","意大利米兰","意大利米兰","意大利米兰","意大利米兰"],img:[9,9,9,9,9],main:["在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。"]},
    {title:["瑞士","瑞士","瑞士","瑞士","瑞士"],img:[10,10,10,10,10],main:["在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。"]},
    {title:["马尔代夫 ","马尔代夫  ","马尔代夫 ","马尔代夫  ","马尔代夫 "],img:[11,11,11,11,11],main:["在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。"]},
    {title:["台北","台北","台北","台北","台北"],img:[12,12,12,12,12],main:["在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。","在北半球处于寒冷的冬季的时候，南半球的新西兰正好春暖花开。"]},]
    var mmUl1 = document.getElementById("mm-ul1");
    var mmLi1 = mmUl1.getElementsByTagName("li");
    var mmUl2 = document.getElementById("mm-ul2");
    for(var mm1 = 0;mm1<mmJson[0].title.length;mm1++){
      mmUl2.innerHTML += "<li class='mm-li1'><div class='mm-w'><p>" + mmJson[0].title[mm1] + "</p><span>" + mmJson[0].main[mm1] + "</span></div></li>";
      var mmLi2 = mmUl2.getElementsByTagName("li")[mm1];
      mmLi2.style.backgroundImage = "url(llq-img/des-b-" + mmJson[0].img[mm1]+ ".jpg)";
      mmLi2 = null; 
    }
    for(var mm2 = 0;mm2<mmLi1.length;mm2++){
      mmLi1[mm2].index = mm2;
      mmLi1[mm2].onmouseover = function(){
        for(var mm3 = 0;mm3<mmLi1.length;mm3++){
          mmLi1[mm3].className = "";
        }
        this.className = "mmOn";
        mmUl2.innerHTML = "";
        for(var mm4 = 0;mm4<mmJson[0].title.length;mm4++){
          mmUl2.innerHTML += "<li class='mm-li1'><div class='mm-w'><p>" + mmJson[this.index].title[mm4] + "</p><span>" + mmJson[this.index].main[mm4] + "</span></div></li>";
          var mmLi2 = mmUl2.getElementsByTagName("li")[mm4];
          mmLi2.style.backgroundImage = "url(llq-img/des-b-" + mmJson[this.index].img[mm4]+ ".jpg)";
        }
      }
    }
};
