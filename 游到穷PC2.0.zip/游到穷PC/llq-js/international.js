// 轮播图
var lbt = document.getElementById("lbt");
var timg = document.getElementById("timg");
var tmini = document.getElementById("tmini");
var imgs = timg.getElementsByTagName("li");
var minis = tmini.getElementsByTagName("li");
var now = 0;
function go() {//显示效果
  for (var i = 0; i < imgs.length; i++) {
    minis[i].className = "";
    imgs[i].style.opacity = "0";
  }
  minis[now].className = "imgon";
  imgs[now].style.opacity = "1";
}
function next() {//轮播
  now++;
  if (now == imgs.length) {
    now = 0;
  }
  go();
}
var times = null;
//   计时器的开启与关闭
times = setInterval(next, 1500);
lbt.onmouseover = function() { 
  clearInterval(times);
};
lbt.onmouseout = function() {
  times = setInterval(next, 1500);
};
for (let z = 0; z < minis.length; z++) {// 小图标效果
  minis[z].index = z;
  minis[z].onmouseover = function() {
    now = this.index;
    go();
  };
}
//   机票top
var sp_ul1 = document.getElementById("sp_ul1");
var sp_li1 = sp_ul1.getElementsByTagName("li");
var sp_li2 = document.getElementsByClassName("sp_ul");
for(var sp = 0;sp<sp_li1.length;sp++){
    sp_li1[sp].index = sp;
    sp_li1[sp].onclick = function(){
      for(var sp1 = 0;sp1<sp_li1.length;sp1++){
          sp_li1[sp1].className = "";
          sp_li2[sp1].style.display = "none";
      }
      this.className = "spOn";
      sp_li2[this.index].style.display = "block";
    }
}

var imJson = {img:[1,1,1,1,1],
    title:["多出发地 - 东京 大阪 福冈市等地","多出发地 - 东京 大阪 福冈市等地","多出发地 - 东京 大阪 福冈市等地","多出发地 - 东京 大阪 福冈市等地","多出发地 - 东京 大阪 福冈市等地"],
    main:["[樱花季/清明/五一/端午|拒签全退]北京/天津直飞日本东京/大阪/名古屋/札幌/冲绳3-30天机票(1人/2人起订,可选首晚酒店+全程WiFi)",
      "[樱花季/清明/五一/端午|拒签全退]北京/天津直飞日本东京/大阪/名古屋/札幌/冲绳3-30天机票(1人/2人起订,可选首晚酒店+全程WiFi)",
      "[樱花季/清明/五一/端午|拒签全退]北京/天津直飞日本东京/大阪/名古屋/札幌/冲绳3-30天机票(1人/2人起订,可选首晚酒店+全程WiFi)",
      "[樱花季/清明/五一/端午|拒签全退]北京/天津直飞日本东京/大阪/名古屋/札幌/冲绳3-30天机票(1人/2人起订,可选首晚酒店+全程WiFi)",
      "[樱花季/清明/五一/端午|拒签全退]北京/天津直飞日本东京/大阪/名古屋/札幌/冲绳3-30天机票(1人/2人起订,可选首晚酒店+全程WiFi)"],
    price:[1099,1098,1097,1096,1095],
    num:[7751,6521,5131,4215,3215]
}
var im_ul = document.getElementById("im_ul");
for(var im = 0;im<imJson.img.length;im++){
  im_ul.innerHTML += "<li><div class='im-left'><img src='llq-img/inter-a-"+imJson.img[im]+".jpg'><div><h5>机票</h5><h4>"+imJson.title[im]+"</h4></div></div><div class='im-right'><h1>"+
      imJson.main[im]+"</h1><div><span>赠WIFI</span><span>直飞航班</span><span>行李升级</span></div><h2>￥<em>"+imJson.price[im]+"</em></h2><h3>元起</h3></div><div class='im-bottom'><span><em>"+
      imJson.price[im]+"</em> 件已售</span><p>立即预定</p></div></li>"
}