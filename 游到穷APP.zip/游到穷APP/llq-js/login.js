function code1(btn) {
    var showCode1 = document.getElementById("showCode1");
    var a = 60;
    var go = setInterval(function () {
        a--;
        btn.innerHTML =  "重新获取("+a +"s)";
        btn.setAttribute("disabled",true);//添加属性 disabled=true 鼠标不可点击
        btn.style.backgroundColor = "#008464";
        if (a < 0) {
            btn.innerHTML = "获取验证码";
            btn.removeAttribute("disabled");
            btn.style.backgroundColor = "#00BE90";
            clearInterval(go);
        }
    }, 1000)
    showCode1.style.display = "block";
}
// window.onload = function(){
    var title = document.getElementById("title");
    var login2 = title.getElementsByTagName("span");
    var uls = document.getElementsByClassName("uls");
    var showCode = document.getElementById("showCode");
    var tips = document.getElementsByClassName("tips");
    var go = document.getElementsByClassName("go");
    for(var i = 0;i < login2.length;i++){//快速登录和账号登录选项卡切换
        login2[i].index = i;
        login2[i].onclick = function(){
            // console.log(1)
            for(var j = 0;j<login2.length;j++){
                login2[j].className = "";
                uls[j].style.display = "none";
                // console.log(2);
            }
        this.className = "on";
        uls[this.index].style.display = "block";
        }
    }
    // 验证码
    function code(where){
        var str = "ABCDEFGHIGKLMNOPQRSTUVWXYZ0123456789";
        var strCode = "";
        for(var i = 0 ;i<4;i++){
            var position = Math.floor(Math.random()*36);
            strCode +=str.substring(position,position+1);
        }
        where.innerHTML = strCode;
    };
    code(showCode);
    showCode.onclick = function(){
        code(showCode);
    }
    code(showCode1);
    //表单验证
    var i1 = document.getElementById("inp1");
    var getCode = document.getElementById("getCode");
    i1.onblur = function(){
        var lv1 = /^(13[0-9]|14[5|7]|15[0|1|2|3|5|6|7|8|9]|18[0|1|2|3|5|6|7|8|9])\d{8}$/;

        if(i1.value == ""){ //手机账号为空
            tips[0].innerHTML = "手机账号不能为空"; 
        }else if (lv1.test(i1.value)){//手机账号格式
            tips[0].innerHTML = "";
            getCode.style.backgroundColor = "#00BE90";
            getCode.removeAttribute("disabled");
        }else{//
            tips[0].innerHTML = "手机账号格式不正确";
        }
    }
    //验证码验证
    var i2 = document.getElementById("inp2");
    var btn1 = document.getElementById("btn1");
    i2.onblur = function(){
        if(i2.value == ""){
            tips[1].innerHTML = "验证码不能为空";
        }else if(i2.value.toUpperCase() == showCode1.innerHTML){
            tips[1].innerHTML = "";
        }else{
            tips[1].innerHTML = "验证码错误";
        }
    }
    btn1.onclick = function(){
        if(i1.value == ""){
            tips[0].innerHTML = "手机账号不能为空"; 
        }else if(i2.value == ""){
            tips[1].innerHTML = "验证码不能为空";
        }
        if(i2.value.toUpperCase() == showCode1.innerHTML){
            alert("登录成功"); 
            go[0].href = "index.html";

        } 
    }
    var i3 = document.getElementById("inp3");
    var i4 = document.getElementById("inp4");
    var i5 = document.getElementById("inp5");
    var btn2 = document.getElementById("btn2");
    var showCode = document.getElementById("showCode");
    i3.onblur = function(){
        if(i3.value == ""){
            tips[2].innerHTML = "请输入账号"
        }else{
            tips[2].innerHTML = "";
        }
    }
    i4.onblur = function(){
        if(i4.value == ""){
            tips[3].innerHTML = "请输入密码"
        }else{
            tips[3].innerHTML = "";
        }
    }
    i5.onblur = function(){
        if(i5.value == ""){
            tips[4].innerHTML = "请输入验证码"
        }else if(showCode.innerHTML != i5.value.toUpperCase()){
            tips[4].innerHTML = "验证码错误";
        }else{
            tips[4].innerHTML = "";
            console.log(1)
            go[0].href = "index.html";

        }
    }
    btn2.onclick = function(){

        if(i3.value == ""){
            console.log(2)
            tips[2].innerHTML = "请输入账号";
        }else if(i4.value == ""){
            console.log(3)
            tips[3].innerHTML = "请输入密码";
        }else if(i5.value == ""){
            console.log(4)
            tips[4].innerHTML = "请输入验证码";
        }else if(showCode.innerHTML != i5.value.toUpperCase()){
            console.log(5)
            tips[4].innerHTML = "验证码错误";
        }else{
            console.log(2)
            alert("登录成功")
            go[1].href = "index.html";
        }
    }
    
// }