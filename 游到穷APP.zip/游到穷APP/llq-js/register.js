function getCode(btn) {
    var a = 60;
    var go = setInterval(function () {
        a--;
        btn.innerHTML =  "重新获取("+a +"s)";
        btn.setAttribute("disabled",true);//添加属性 disabled=true 鼠标不可点击
        btn.style.backgroundColor = "#008464";
        if (a < 0) {
            btn.innerHTML = "获取验证码";
            btn.removeAttribute("disabled");
            btn.style.backgroundColor = "#00BE90";
            clearInterval(go);
        }
    }, 1000)
    showCode.style.display = "block";
    code(showCode);
}
//验证码
function code(where){
    var str = "ABCDEFGHIGKLMNOPQRSTUVWXYZ0123456789";
    var strCode = "";
    for(var i = 0 ;i<4;i++){
        var position = Math.floor(Math.random()*36);
        strCode +=str.substring(position,position+1);
    }
    where.innerHTML = strCode;
}
var showCode = document.getElementById("showCode");        
var inp = document.getElementsByTagName("input");
var tips = document.getElementsByClassName("tips");
var go = document.getElementById("go");
var btn1 = go.getElementsByTagName("button")[0];
var lv1 = /^(13[0-9]|14[5|7]|15[0|1|2|3|5|6|7|8|9]|18[0|1|2|3|5|6|7|8|9])\d{8}$/;
// 用户名
inp[0].onblur = function(){
    if(inp[0].value==""){
        tips[0].innerHTML = "用户名不能为空";
    }else{
        tips[0].innerHTML = "";
    }
}
inp[1].onblur = function(){
    if(inp[1].value==""){
        tips[1].innerHTML = "密码不能为空";
    }else{
        tips[1].innerHTML = "";
    }
}
inp[2].onblur = function(){
    if(inp[2].value==""){
        tips[2].innerHTML = "请再次输入密码";
    }else if(inp[2].value != inp[1].value){
        tips[2].innerHTML = "两次密码输入错误";
    }else{
        tips[2].innerHTML = "";
    }
}
inp[3].onblur = function(){
    if(inp[3].value==""){
        tips[3].innerHTML = "请输入手机号";
    }else if(lv1.test(inp[3].value)){
        tips[3].innerHTML = "";
    }else{
        tips[3].innerHTML = "手机格式不正确";
    }
}
inp[4].onblur = function(){
    if(inp[4].value == ""){
        tips[4].innerHTML = "请输入验证码";
    }else if(inp[4].value.toUpperCase() == showCode.innerHTML){
        tips[4].innerHTML = "";
    }else{
        console.log(inp[4].value.toUpperCase()+"--"+showCode.innerHTML)
        tips[4].innerHTML = "验证码输入错误";
    }
}
inp[5].onclick = function(){
    if(inp[5].checked == true){
        btn1.style.backgroundColor = "#00BE90";
        btn1.removeAttribute("disabled");
    }else{
        btn1.style.backgroundColor = "#008464";
        btn1.setAttribute("disabled","true")
    }

}

btn1.onclick = function(){
    if(inp[0].value == ""){
        tips[0].innerHTML = "用户名不能为空";
    }else if(inp[1].value == ""){
        tips[1].innerHTML = "密码不能为空";
    }else if(inp[2].value == ""){
        tips[2].innerHTML = "请再次输入密码";
    }else if(inp[3].value == ""){
        tips[3].innerHTML = "请输入手机号";
    }else if(inp[4].value.toUpperCase() != showCode.innerHTML){
        tips[4].innerHTML = "验证码输入错误";
    }else{
        for(var ts = 0;ts<tips.length;ts++){
            console.log(ts);
            if(tips[ts].innerHTML != ""){
                break;
            }
            if(ts == tips.length-1){
                alert("注册成功");
                go.href = "index.html";
            }
        }
    } 
}